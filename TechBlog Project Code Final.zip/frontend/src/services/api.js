import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Articles API
export const articleService = {
  getAll: async (params = {}) => {
    const response = await axios.get(`${API_URL}/articles`, { params });
    return response.data;
  },

  getBySlug: async (slug) => {
    const response = await axios.get(`${API_URL}/articles/${slug}`);
    return response.data;
  },

  create: async (articleData) => {
    const response = await axios.post(`${API_URL}/articles`, articleData);
    return response.data;
  },

  update: async (id, articleData) => {
    const response = await axios.put(`${API_URL}/articles/${id}`, articleData);
    return response.data;
  },

  delete: async (id) => {
    const response = await axios.delete(`${API_URL}/articles/${id}`);
    return response.data;
  },

  like: async (id) => {
    const response = await axios.post(`${API_URL}/articles/${id}/like`);
    return response.data;
  }
};

// Comments API
export const commentService = {
  getByArticle: async (articleId) => {
    const response = await axios.get(`${API_URL}/comments/article/${articleId}`);
    return response.data;
  },

  create: async (commentData) => {
    const response = await axios.post(`${API_URL}/comments`, commentData);
    return response.data;
  },

  update: async (id, content) => {
    const response = await axios.put(`${API_URL}/comments/${id}`, { content });
    return response.data;
  },

  delete: async (id) => {
    const response = await axios.delete(`${API_URL}/comments/${id}`);
    return response.data;
  },

  like: async (id) => {
    const response = await axios.post(`${API_URL}/comments/${id}/like`);
    return response.data;
  }
};

// Users API
export const userService = {
  getByUsername: async (username) => {
    const response = await axios.get(`${API_URL}/users/${username}`);
    return response.data;
  },

  getArticles: async (username) => {
    const response = await axios.get(`${API_URL}/users/${username}/articles`);
    return response.data;
  },

  follow: async (userId) => {
    const response = await axios.post(`${API_URL}/users/${userId}/follow`);
    return response.data;
  },

  getFollowers: async (userId) => {
    const response = await axios.get(`${API_URL}/users/${userId}/followers`);
    return response.data;
  },

  getFollowing: async (userId) => {
    const response = await axios.get(`${API_URL}/users/${userId}/following`);
    return response.data;
  }
};

export default {
  articles: articleService,
  comments: commentService,
  users: userService
};
