# TechBlog Backend API

## 📋 Overview

RESTful API backend for the TechBlog platform built with Node.js, Express.js, and MongoDB.

## 🛠️ Tech Stack

- **Runtime:** Node.js
- **Framework:** Express.js
- **Database:** MongoDB with Mongoose ODM
- **Authentication:** JWT (JSON Web Tokens)
- **Password Hashing:** bcryptjs
- **Validation:** express-validator

## 📁 Project Structure

```
backend/
├── models/          # Mongoose schemas
│   ├── User.js
│   ├── Article.js
│   └── Comment.js
├── routes/          # API routes
│   ├── auth.js
│   ├── articles.js
│   ├── comments.js
│   └── users.js
├── middleware/      # Custom middleware
│   └── auth.js
├── .env            # Environment variables
├── server.js       # Main server file
└── package.json    # Dependencies
```

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or MongoDB Atlas)

### Steps

1. **Install dependencies:**
```bash
npm install
```

2. **Configure environment variables:**
Create `.env` file with:
```
MONGODB_URI=mongodb://localhost:27017/techblog
JWT_SECRET=your_jwt_secret_key
PORT=5000
NODE_ENV=development
```

3. **Start MongoDB:**
```bash
# If using local MongoDB
mongod
```

4. **Run the server:**
```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

Server will run on `http://localhost:5000`

## 📡 API Endpoints

### Authentication (`/api/auth`)

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/register` | Register new user | No |
| POST | `/login` | Login user | No |
| GET | `/me` | Get current user profile | Yes |
| PUT | `/profile` | Update user profile | Yes |

### Articles (`/api/articles`)

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/` | Get all published articles | No |
| GET | `/:slug` | Get single article | No |
| POST | `/` | Create new article | Yes |
| PUT | `/:id` | Update article | Yes (Author) |
| DELETE | `/:id` | Delete article | Yes (Author) |
| POST | `/:id/like` | Like/unlike article | Yes |

**Query Parameters for GET `/`:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10, max: 50)
- `category` - Filter by category
- `tag` - Filter by tag
- `search` - Text search
- `author` - Filter by author ID

### Comments (`/api/comments`)

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/article/:articleId` | Get article comments | No |
| POST | `/` | Create comment | Yes |
| PUT | `/:id` | Update comment | Yes (Author) |
| DELETE | `/:id` | Delete comment | Yes (Author) |
| POST | `/:id/like` | Like/unlike comment | Yes |

### Users (`/api/users`)

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/:username` | Get user profile | No |
| GET | `/:username/articles` | Get user's articles | No |
| POST | `/:userId/follow` | Follow/unfollow user | Yes |
| GET | `/:userId/followers` | Get user followers | No |
| GET | `/:userId/following` | Get user following | No |

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication.

### How to authenticate:

1. **Register or login** to receive a JWT token
2. **Include token** in all protected requests:
```
Authorization: Bearer <your_jwt_token>
```

### Example using curl:
```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"john","email":"john@example.com","password":"password123"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"password123"}'

# Use token
curl http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## 📊 Database Models

### User
- username (unique, 3-30 chars)
- email (unique, validated)
- password (hashed with bcrypt)
- fullName (optional)
- bio (optional, max 500 chars)
- role (user/admin)
- favoriteArticles (array of Article IDs)
- following/followers (arrays of User IDs)

### Article
- title (5-200 chars)
- slug (auto-generated from title)
- content (min 50 chars)
- excerpt (auto-generated or custom)
- author (User reference)
- category (enum of tech categories)
- tags (array of strings)
- status (draft/published)
- likes (array of User IDs)
- views (number)
- readTime (auto-calculated in minutes)

### Comment
- content (1-1000 chars)
- author (User reference)
- article (Article reference)
- parentComment (optional, for replies)
- likes (array of User IDs)
- isEdited (boolean)

## 🧪 Testing

### Using Postman

1. Import the API endpoints into Postman
2. Set up environment variables:
   - `base_url`: http://localhost:5000
   - `token`: (set after login)

3. Test sequence:
   - Register user
   - Login (save token)
   - Create article
   - Get articles
   - Like article
   - Create comment

### Manual Testing

```bash
# Health check
curl http://localhost:5000/api/health

# Get articles
curl http://localhost:5000/api/articles

# Search articles
curl "http://localhost:5000/api/articles?search=javascript&category=JavaScript"
```

## 🔒 Security Features

- Password hashing with bcrypt
- JWT token-based authentication
- Input validation using express-validator
- CORS enabled for frontend access
- MongoDB injection protection via Mongoose
- Rate limiting (can be added via express-rate-limit)

## 📝 Error Handling

The API returns consistent error responses:

```json
{
  "error": "Error message description"
}
```

Status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request (validation error)
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Internal Server Error

## 🚀 Deployment

### Environment Variables for Production

```
MONGODB_URI=<your_mongodb_atlas_connection_string>
JWT_SECRET=<strong_random_secret>
PORT=5000
NODE_ENV=production
```

### Deployment Platforms
- **Heroku:** Add MongoDB Atlas add-on
- **Railway:** Connect GitHub repo
- **AWS EC2:** Use PM2 for process management
- **Vercel/Netlify:** Not recommended (need persistent connection)

## 📚 Additional Documentation

For detailed API documentation, use tools like:
- Swagger/OpenAPI
- Postman Documentation
- API Blueprint

## 🐛 Known Issues & TODOs

- [ ] Add rate limiting
- [ ] Implement email verification
- [ ] Add image upload functionality
- [ ] Implement caching (Redis)
- [ ] Add comprehensive unit tests
- [ ] Set up API documentation (Swagger)

## 📄 License

MIT License - See LICENSE file for details
