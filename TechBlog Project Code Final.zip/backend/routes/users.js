/**
 * Users Routes
 * User profile and follow operations
 */

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Article = require('../models/Article');
const { authenticate } = require('../middleware/auth');

/**
 * @route   GET /api/users/:username
 * @desc    Get user profile by username
 * @access  Public
 */
router.get('/:username', async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username })
      .select('-password')
      .lean();
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Get user's published articles count
    const articlesCount = await Article.countDocuments({
      author: user._id,
      status: 'published'
    });
    
    res.json({
      user: {
        ...user,
        articlesCount,
        followersCount: user.followers.length,
        followingCount: user.following.length
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
});

/**
 * @route   GET /api/users/:username/articles
 * @desc    Get user's published articles
 * @access  Public
 */
router.get('/:username/articles', async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const articles = await Article.find({
      author: user._id,
      status: 'published'
    })
      .populate('author', 'username fullName')
      .sort({ publishedAt: -1 })
      .lean();
    
    res.json({ articles });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user articles' });
  }
});

/**
 * @route   POST /api/users/:userId/follow
 * @desc    Follow/unfollow a user
 * @access  Private
 */
router.post('/:userId/follow', authenticate, async (req, res) => {
  try {
    if (req.params.userId === req.user._id.toString()) {
      return res.status(400).json({ error: 'Cannot follow yourself' });
    }
    
    const targetUser = await User.findById(req.params.userId);
    
    if (!targetUser) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const currentUser = await User.findById(req.user._id);
    
    const followingIndex = currentUser.following.indexOf(targetUser._id);
    
    if (followingIndex === -1) {
      // Follow
      currentUser.following.push(targetUser._id);
      targetUser.followers.push(currentUser._id);
    } else {
      // Unfollow
      currentUser.following.splice(followingIndex, 1);
      const followerIndex = targetUser.followers.indexOf(currentUser._id);
      targetUser.followers.splice(followerIndex, 1);
    }
    
    await currentUser.save();
    await targetUser.save();
    
    res.json({
      message: followingIndex === -1 ? 'User followed' : 'User unfollowed',
      isFollowing: followingIndex === -1
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process follow' });
  }
});

/**
 * @route   GET /api/users/:userId/followers
 * @desc    Get user's followers
 * @access  Public
 */
router.get('/:userId/followers', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId)
      .populate('followers', 'username fullName bio')
      .lean();
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ followers: user.followers });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch followers' });
  }
});

/**
 * @route   GET /api/users/:userId/following
 * @desc    Get users that this user follows
 * @access  Public
 */
router.get('/:userId/following', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId)
      .populate('following', 'username fullName bio')
      .lean();
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ following: user.following });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch following' });
  }
});

module.exports = router;
