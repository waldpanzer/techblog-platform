/**
 * Articles Routes
 * CRUD operations for blog articles
 */

const express = require('express');
const router = express.Router();
const { body, validationResult, query } = require('express-validator');
const Article = require('../models/Article');
const Comment = require('../models/Comment');
const { authenticate, optionalAuth } = require('../middleware/auth');

/**
 * @route   GET /api/articles
 * @desc    Get all published articles with filters
 * @access  Public
 */
router.get('/', [
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 50 }),
  query('category').optional().trim(),
  query('tag').optional().trim(),
  query('search').optional().trim(),
  query('author').optional().isMongoId()
], optionalAuth, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Build query
    const query = { status: 'published' };
    
    if (req.query.category) {
      query.category = req.query.category;
    }
    
    if (req.query.tag) {
      query.tags = req.query.tag;
    }
    
    if (req.query.author) {
      query.author = req.query.author;
    }
    
    if (req.query.search) {
      query.$text = { $search: req.query.search };
    }
    
    // Fetch articles
    const articles = await Article.find(query)
      .populate('author', 'username fullName')
      .sort({ publishedAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();
    
    const total = await Article.countDocuments(query);
    
    res.json({
      articles,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Fetch articles error:', error);
    res.status(500).json({ error: 'Failed to fetch articles' });
  }
});

/**
 * @route   GET /api/articles/:slug
 * @desc    Get single article by slug
 * @access  Public
 */
router.get('/:slug', optionalAuth, async (req, res) => {
  try {
    const article = await Article.findOne({ slug: req.params.slug })
      .populate('author', 'username fullName bio');
    
    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    // Only show published articles or own drafts
    if (article.status === 'draft' && 
        (!req.user || article.author._id.toString() !== req.user._id.toString())) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    // Increment views
    article.views += 1;
    await article.save();
    
    res.json({ article });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch article' });
  }
});

/**
 * @route   POST /api/articles
 * @desc    Create new article
 * @access  Private
 */
router.post('/', authenticate, [
  body('title').trim().isLength({ min: 5, max: 200 }),
  body('content').trim().isLength({ min: 50 }),
  body('category').isIn(['JavaScript', 'Python', 'Web Development', 'Mobile Development', 
                         'DevOps', 'AI & ML', 'Databases', 'Cloud Computing', 'Other']),
  body('tags').optional().isArray(),
  body('status').optional().isIn(['draft', 'published'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const { title, content, excerpt, category, tags, coverImage, status } = req.body;
    
    const article = new Article({
      title,
      content,
      excerpt,
      category,
      tags: tags || [],
      coverImage,
      status: status || 'draft',
      author: req.user._id
    });
    
    await article.save();
    await article.populate('author', 'username fullName');
    
    res.status(201).json({
      message: 'Article created successfully',
      article
    });
  } catch (error) {
    console.error('Create article error:', error);
    res.status(500).json({ error: 'Failed to create article' });
  }
});

/**
 * @route   PUT /api/articles/:id
 * @desc    Update article
 * @access  Private (Author only)
 */
router.put('/:id', authenticate, [
  body('title').optional().trim().isLength({ min: 5, max: 200 }),
  body('content').optional().trim().isLength({ min: 50 }),
  body('category').optional(),
  body('tags').optional().isArray(),
  body('status').optional().isIn(['draft', 'published'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    // Check ownership
    if (article.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    // Update fields
    const allowedUpdates = ['title', 'content', 'excerpt', 'category', 'tags', 'coverImage', 'status'];
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        article[field] = req.body[field];
      }
    });
    
    await article.save();
    await article.populate('author', 'username fullName');
    
    res.json({
      message: 'Article updated successfully',
      article
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update article' });
  }
});

/**
 * @route   DELETE /api/articles/:id
 * @desc    Delete article
 * @access  Private (Author only)
 */
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    if (article.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    // Delete associated comments
    await Comment.deleteMany({ article: article._id });
    
    await article.deleteOne();
    
    res.json({ message: 'Article deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete article' });
  }
});

/**
 * @route   POST /api/articles/:id/like
 * @desc    Like/unlike article
 * @access  Private
 */
router.post('/:id/like', authenticate, async (req, res) => {
  try {
    const article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    const likeIndex = article.likes.indexOf(req.user._id);
    
    if (likeIndex === -1) {
      // Like
      article.likes.push(req.user._id);
    } else {
      // Unlike
      article.likes.splice(likeIndex, 1);
    }
    
    await article.save();
    
    res.json({
      message: likeIndex === -1 ? 'Article liked' : 'Article unliked',
      likesCount: article.likes.length,
      isLiked: likeIndex === -1
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process like' });
  }
});

module.exports = router;
