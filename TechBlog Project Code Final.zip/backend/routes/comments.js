/**
 * Comments Routes
 * CRUD operations for article comments
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Comment = require('../models/Comment');
const Article = require('../models/Article');
const { authenticate } = require('../middleware/auth');

/**
 * @route   GET /api/comments/article/:articleId
 * @desc    Get all comments for an article
 * @access  Public
 */
router.get('/article/:articleId', async (req, res) => {
  try {
    const comments = await Comment.find({ 
      article: req.params.articleId,
      parentComment: null // Only root comments
    })
      .populate('author', 'username fullName')
      .sort({ createdAt: -1 })
      .lean();
    
    // Get replies for each comment
    const commentsWithReplies = await Promise.all(
      comments.map(async (comment) => {
        const replies = await Comment.find({ parentComment: comment._id })
          .populate('author', 'username fullName')
          .sort({ createdAt: 1 })
          .lean();
        
        return { ...comment, replies };
      })
    );
    
    res.json({ comments: commentsWithReplies });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

/**
 * @route   POST /api/comments
 * @desc    Create a new comment
 * @access  Private
 */
router.post('/', authenticate, [
  body('content').trim().isLength({ min: 1, max: 1000 }),
  body('articleId').isMongoId(),
  body('parentCommentId').optional().isMongoId()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const { content, articleId, parentCommentId } = req.body;
    
    // Verify article exists
    const article = await Article.findById(articleId);
    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }
    
    // If replying, verify parent comment exists
    if (parentCommentId) {
      const parentComment = await Comment.findById(parentCommentId);
      if (!parentComment) {
        return res.status(404).json({ error: 'Parent comment not found' });
      }
    }
    
    const comment = new Comment({
      content,
      article: articleId,
      author: req.user._id,
      parentComment: parentCommentId || null
    });
    
    await comment.save();
    await comment.populate('author', 'username fullName');
    
    res.status(201).json({
      message: 'Comment posted successfully',
      comment
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to post comment' });
  }
});

/**
 * @route   PUT /api/comments/:id
 * @desc    Update a comment
 * @access  Private (Author only)
 */
router.put('/:id', authenticate, [
  body('content').trim().isLength({ min: 1, max: 1000 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    
    if (comment.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    comment.content = req.body.content;
    comment.isEdited = true;
    
    await comment.save();
    await comment.populate('author', 'username fullName');
    
    res.json({
      message: 'Comment updated successfully',
      comment
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update comment' });
  }
});

/**
 * @route   DELETE /api/comments/:id
 * @desc    Delete a comment
 * @access  Private (Author only)
 */
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    
    if (comment.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    // Delete replies first
    await Comment.deleteMany({ parentComment: comment._id });
    
    await comment.deleteOne();
    
    res.json({ message: 'Comment deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete comment' });
  }
});

/**
 * @route   POST /api/comments/:id/like
 * @desc    Like/unlike a comment
 * @access  Private
 */
router.post('/:id/like', authenticate, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    
    const likeIndex = comment.likes.indexOf(req.user._id);
    
    if (likeIndex === -1) {
      comment.likes.push(req.user._id);
    } else {
      comment.likes.splice(likeIndex, 1);
    }
    
    await comment.save();
    
    res.json({
      message: likeIndex === -1 ? 'Comment liked' : 'Comment unliked',
      likesCount: comment.likes.length
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process like' });
  }
});

module.exports = router;
