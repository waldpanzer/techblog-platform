# 🚀 TechBlog Platform

## Full-Stack Blogging Platform for Technology Enthusiasts

### 📋 Project Information

- **Course:** Project Java and Web Development (DLBCSPJWD01)
- **Project Type:** Portfolio - Full-Stack Web Application
- **GitHub Repository:** https://github.com/yourusername/techblog-platform

---

## 📝 Project Overview

TechBlog is a modern, full-stack web application designed to provide a comprehensive blogging platform for technology enthusiasts and developers. The platform enables content creators to publish technical articles, tutorials, and insights while fostering community engagement through comments, likes, and user interactions.

### 🎯 Key Features

1. **Article Management**
   - Create, edit, and publish blog posts with rich text editor
   - Support for code snippets, images, and formatted content
   - Draft and published states
   - Categories and tags for organization

2. **User Authentication**
   - Secure registration and login system
   - JWT-based authentication
   - Password hashing with bcrypt
   - Protected routes

3. **Comment System**
   - Threaded comments on articles
   - Reply functionality
   - Like/unlike comments
   - Edit and delete own comments

4. **Search & Filter**
   - Full-text search across articles
   - Filter by category, tags, and author
   - Pagination support

5. **User Engagement**
   - Like/favorite articles
   - Follow/unfollow authors
   - User profiles with bio and stats
   - View count tracking

6. **Responsive Design**
   - Mobile-first approach
   - Works seamlessly on desktop, tablet, and mobile
   - Clean, modern UI

---

## 🛠️ Technology Stack

### Frontend
- **Framework:** React.js 18.2
- **Routing:** React Router v6
- **HTTP Client:** Axios
- **Rich Text Editor:** React Quill
- **Styling:** CSS3 with custom responsive design
- **State Management:** React Context API

### Backend
- **Runtime:** Node.js
- **Framework:** Express.js 4.18
- **Database:** MongoDB with Mongoose ODM
- **Authentication:** JWT (jsonwebtoken)
- **Password Hashing:** bcryptjs
- **Validation:** express-validator
- **Security:** CORS, helmet (production)

### Development Tools
- **Version Control:** Git & GitHub
- **Code Editor:** VS Code
- **API Testing:** Postman
- **Package Manager:** npm

---

## 📁 Project Structure

```
techblog-platform/
├── backend/                 # Node.js + Express API
│   ├── models/             # Mongoose schemas
│   │   ├── User.js
│   │   ├── Article.js
│   │   └── Comment.js
│   ├── routes/             # API endpoints
│   │   ├── auth.js
│   │   ├── articles.js
│   │   ├── comments.js
│   │   └── users.js
│   ├── middleware/         # Custom middleware
│   │   └── auth.js
│   ├── .env               # Environment variables
│   ├── server.js          # Main server file
│   ├── package.json
│   └── README.md
│
├── frontend/               # React application
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/    # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── services/      # API services
│   │   ├── context/       # React Context
│   │   ├── utils/         # Utility functions
│   │   ├── styles/        # CSS files
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── README.md
│
├── .gitignore
└── README.md              # This file
```

---

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas account)
- Git

### Step 1: Clone the Repository
```bash
git clone https://github.com/yourusername/techblog-platform.git
cd techblog-platform
```

### Step 2: Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file
cat > .env << EOF
MONGODB_URI=mongodb://localhost:27017/techblog
JWT_SECRET=your_jwt_secret_key_change_in_production
PORT=5000
NODE_ENV=development
EOF

# Start MongoDB (if using local)
# In a separate terminal:
mongod

# Start the backend server
npm run dev
# Server runs on http://localhost:5000
```

### Step 3: Frontend Setup

```bash
# Open new terminal and navigate to frontend
cd frontend

# Install dependencies
npm install

# Start the React app
npm start
# App runs on http://localhost:3000
```

---

## 📡 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123",
  "fullName": "John Doe"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

### Article Endpoints

#### Get All Articles
```http
GET /api/articles?page=1&limit=10&category=JavaScript
```

#### Create Article
```http
POST /api/articles
Authorization: Bearer {token}
Content-Type: application/json

{
  "title": "Getting Started with React Hooks",
  "content": "Article content here...",
  "category": "JavaScript",
  "tags": ["react", "hooks", "javascript"],
  "status": "published"
}
```

#### Get Single Article
```http
GET /api/articles/:slug
```

#### Like Article
```http
POST /api/articles/:id/like
Authorization: Bearer {token}
```

### Comment Endpoints

#### Get Article Comments
```http
GET /api/comments/article/:articleId
```

#### Create Comment
```http
POST /api/comments
Authorization: Bearer {token}
Content-Type: application/json

{
  "content": "Great article!",
  "articleId": "article_id_here",
  "parentCommentId": null
}
```

### User Endpoints

#### Get User Profile
```http
GET /api/users/:username
```

#### Follow User
```http
POST /api/users/:userId/follow
Authorization: Bearer {token}
```

---

## 🎨 Features Demonstration

### 1. User Registration & Authentication
- New users can register with email, username, and password
- Passwords are securely hashed using bcrypt
- JWT tokens provided upon login (7-day expiration)
- Protected routes require authentication

### 2. Article Creation & Management
- Rich text editor with formatting options
- Support for headings, lists, links, and code blocks
- Auto-generated URL slugs from titles
- Read time calculation based on word count
- Draft and published states

### 3. Responsive Design
- Mobile-first CSS approach
- Flexible grid layouts
- Media queries for tablet and desktop
- Touch-friendly interface elements

### 4. Search & Discovery
- Full-text search across article titles and content
- Filter by multiple categories
- Tag-based filtering
- Pagination for large result sets

### 5. Community Engagement
- Like articles and comments
- Follow favorite authors
- Threaded comment discussions
- User profile pages with stats

---

## 🧪 Testing

### Manual Testing Checklist

#### Authentication
- [ ] User can register with valid credentials
- [ ] User cannot register with duplicate email/username
- [ ] User can login with correct credentials
- [ ] User cannot login with wrong password
- [ ] JWT token is stored and used for protected routes

#### Articles
- [ ] User can create new article
- [ ] Article appears in list after creation
- [ ] User can edit own articles
- [ ] User cannot edit others' articles
- [ ] Article search works correctly
- [ ] Category filtering works
- [ ] Pagination works

#### Comments
- [ ] User can post comments on articles
- [ ] User can reply to comments (threading)
- [ ] User can edit own comments
- [ ] User can delete own comments
- [ ] Comment likes work correctly

#### Responsive Design
- [ ] Layout adapts on mobile (< 768px)
- [ ] Layout adapts on tablet (768px - 1024px)
- [ ] Layout works on desktop (> 1024px)
- [ ] Touch interactions work on mobile
- [ ] All text is readable on small screens

### Using Postman

1. Import the API collection (see `/docs/postman-collection.json`)
2. Set environment variables
3. Run test sequence:
   - Register → Login → Create Article → Comment → Like

---

## 🔐 Security Features

- **Password Security:** bcrypt hashing with salt rounds
- **Authentication:** JWT tokens with expiration
- **Input Validation:** express-validator for all inputs
- **SQL/NoSQL Injection:** Mongoose escaping
- **CORS:** Configured for frontend origin
- **Environment Variables:** Sensitive data in .env
- **Authorization:** Route-level permission checks

---

## 📱 Responsive Design

### Breakpoints
- **Mobile:** < 768px
- **Tablet:** 768px - 1024px
- **Desktop:** > 1024px

### Mobile Optimizations
- Hamburger menu for navigation
- Stack layout for content
- Touch-optimized buttons (min 44px)
- Reduced font sizes for small screens
- Simplified forms

---

## 🚀 Deployment

### Backend Deployment (Heroku Example)

```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create techblog-api

# Set environment variables
heroku config:set MONGODB_URI=your_mongodb_atlas_uri
heroku config:set JWT_SECRET=your_secret
heroku config:set NODE_ENV=production

# Deploy
git push heroku main
```

### Frontend Deployment (Vercel Example)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
cd frontend
vercel

# Set environment variables in Vercel dashboard
REACT_APP_API_URL=https://your-api.herokuapp.com
```

---

## 📈 Future Enhancements

- [ ] Image upload for articles and profiles
- [ ] Email notifications for comments
- [ ] Rich text editor with code syntax highlighting
- [ ] Article bookmarking
- [ ] User badges and reputation system
- [ ] Admin dashboard
- [ ] Article analytics (views, engagement)
- [ ] Social media sharing
- [ ] Dark mode
- [ ] Multi-language support

---

## 🐛 Known Issues

- Image upload not yet implemented
- No email verification for registration
- Limited error handling on frontend
- No rate limiting on API endpoints

---

## 👥 Contributing

This is a portfolio project, but suggestions are welcome!

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

---

## 📄 License

MIT License - feel free to use this project for learning purposes.

---

## 📞 Contact

- **Developer:** [Your Name]
- **Email:** your.email@example.com
- **GitHub:** https://github.com/yourusername
- **LinkedIn:** https://linkedin.com/in/yourprofile

---

## 🙏 Acknowledgments

- IU International University of Applied Sciences
- Course: Project Java and Web Development (DLBCSPJWD01)
- React.js and Node.js communities
- MongoDB documentation
- Stack Overflow community

---

## 📚 Learning Resources Used

- React Official Documentation
- Express.js Guide
- MongoDB University
- JWT.io
- MDN Web Docs
- freeCodeCamp

---

**Built with ❤️ for the tech community**
